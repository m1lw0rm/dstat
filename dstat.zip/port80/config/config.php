
<?php
/*
 _   __                          _ 
| | / /                         | |
| |/ /  ___  _ __  _ __ __ _  __| |
|    \ / _ \| '_ \| '__/ _` |/ _` |
| |\  \ (_) | | | | | | (_| | (_| |
\_| \_/\___/|_| |_|_|  \__,_|\__,_|

*/

//EN - FR
//CONFIGURATION - CONFIG


//SITE NAME - Nom du site
$sitename = 'ANACHAKHACKER.COM';


// CAPS ONLY - Majuscule seulement


//Bit or byte - Bit ou octet
// US=bit and/et EU= octet
$num = 'US';

//Data transferred or received  -  Donnée transférée ou recus
//RX = received/recus TX = transferred/transféerée
$datatype = 'RX';

//Language - Langue
//FR = francais/french - EN = english/anglais
$lang = 'EN';

//IP OF SERVER - Ip du serveur
$ip = $_SERVER['46.166.185.62'];

//Name of interface - Nom de l'interface
//Usually : 'eth0' - Generalement :'eth0'
$interface = 'eth0';
?>
